import AppController from './controller/app_controller.js'

;(async function () {
  $(document).ready(function () {
    let app = new AppController()
  })
})()
